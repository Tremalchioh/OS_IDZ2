#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <cstdlib>
#include<string>
#include <csignal>

const int NUM_PHILOSOPHERS = 5;

int main() {

    sem_t *forks = static_cast<sem_t *>(mmap(nullptr, sizeof(sem_t) * NUM_PHILOSOPHERS, PROT_READ | PROT_WRITE,
                                             MAP_SHARED | MAP_ANONYMOUS, -1, 0));
    sem_t *waiter = static_cast<sem_t *>(mmap(nullptr, sizeof(sem_t), PROT_READ | PROT_WRITE,
                                              MAP_SHARED | MAP_ANONYMOUS, -1, 0));

    // Initialize semaphores
    sem_init(waiter, 1, 4);  // Waiter semaphore initialized to 4
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        sem_init(&forks[i], 1, 1);  // Fork semaphores initialized to 1
    }
    while (true) {
        std::cout << "Type start to start processes, when started, type end to end them"<<std::endl;
        std::string inputIntroString = "";
        std::cin>>inputIntroString;
        if(inputIntroString=="start")
            break;
    }
    for (int i = 0; i < NUM_PHILOSOPHERS + 1; i++) {
        if (i == 5) {
            while (true) {
                std::string inputCancelString;
                std::cin >> inputCancelString;
                if (inputCancelString == "end") {
                    // Cleanup semaphores
                    sem_destroy(waiter);
                    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
                        sem_destroy(&forks[i]);
                    }

                    // Unmap shared memory
                    munmap(forks, sizeof(sem_t) * NUM_PHILOSOPHERS);
                    munmap(waiter, sizeof(sem_t));
                    killpg(getpgrp(), SIGTERM); // Exiting processes including child ones
                }
            }
        } else {
            pid_t pid = fork();
            if (pid == 0) {  // Child process
                srand(time(NULL) ^ (getpid() << 16));  // Seed random with PID for uniqueness
                while (true) {
                    std::cout << "Philosopher " << i << " is thinking.\n";
                    sleep(rand() % 3 + 3);

                    // Ask waiter for permission
                    sem_wait(waiter);
                    sem_wait(&forks[i]);  // Left fork
                    std::cout << "Philosopher " << i << " took left fork.\n";
                    sem_wait(&forks[(i + 1) % NUM_PHILOSOPHERS]);  // Right fork
                    std::cout << "Philosopher " << i << " is eating.\n";

                    sleep(rand() % 3 + 3);

                    sem_post(&forks[i]);  // Put down left fork
                    sem_post(&forks[(i + 1) % NUM_PHILOSOPHERS]);  // Put down right fork
                    sem_post(waiter);  // Notify waiter
                }
                exit(0);  // Terminate child process
            }
        }
    }

    // Wait for all child processes to finish
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        wait(NULL);
    }

    // Cleanup semaphores
    sem_destroy(waiter);
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        sem_destroy(&forks[i]);
    }

    // Unmap shared memory
    munmap(forks, sizeof(sem_t) * NUM_PHILOSOPHERS);
    munmap(waiter, sizeof(sem_t));

    return 0;


}
