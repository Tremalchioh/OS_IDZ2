#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <cstdlib>
#include <string>
#include <csignal>

const int NUM_PHILOSOPHERS = 5;

int main() {
    // Имена для семафоров
    const char *waiter_name = "/waiter_sem";
    const char *fork_base_name = "/fork_sem_";

    // Создание именованных семафоров
    sem_t *waiter = sem_open(waiter_name, O_CREAT, 0666, 4);
    sem_t *forks[NUM_PHILOSOPHERS];

    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        std::string fork_name = fork_base_name + std::to_string(i);
        forks[i] = sem_open(fork_name.c_str(), O_CREAT, 0666, 1);
    }

    // Ждем команды на запуск
    while (true) {
        std::cout << "Type start to start processes, or end to end them" << std::endl;
        std::string input;
        std::cin >> input;
        if (input == "start") {
            break;
        } else if (input == "end") {
            // Выход без запуска процессов
            return 0;
        }
    }

    for (int i = 0; i < NUM_PHILOSOPHERS + 1; i++) {
        if (i == 5) {
            while (true) {
                std::string inputCancelString;
                std::cin >> inputCancelString;
                if (inputCancelString == "end") {
                    // Cleanup semaphores
                    sem_close(waiter);
                    sem_unlink(waiter_name);
                    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
                        sem_close(forks[i]);
                        std::string fork_name = fork_base_name + std::to_string(i);
                        sem_unlink(fork_name.c_str());

                    }
                    killpg(getpgrp(), SIGTERM);
                }
            }
        }
        pid_t pid = fork();
        if (pid == 0) {  // Child process
            srand(time(NULL) ^ (getpid() << 16));  // Seed random with PID for uniqueness
            while (true) {
                std::cout << "Philosopher " << i << " is thinking.\n";
                sleep(rand() % 3 + 3);

                sem_wait(waiter);
                sem_wait(forks[i]);  // Left fork
                std::cout << "Philosopher " << i << " took left fork.\n";
                sem_wait(forks[(i + 1) % NUM_PHILOSOPHERS]);  // Right fork
                std::cout << "Philosopher " << i << " is eating.\n";

                sleep(rand() % 3 + 3);

                sem_post(forks[i]);  // Put down left fork
                sem_post(forks[(i + 1) % NUM_PHILOSOPHERS]);  // Put down right fork
                sem_post(waiter);  // Notify waiter
            }
            exit(0);  // Terminate child process
        }
    }

    // Wait for all child processes to finish
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        wait(NULL);
    }

    // Cleanup semaphores
    sem_close(waiter);
    sem_unlink(waiter_name);
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        sem_close(forks[i]);
        std::string fork_name = fork_base_name + std::to_string(i);
        sem_unlink(fork_name.c_str());
    }

    return 0;
}
