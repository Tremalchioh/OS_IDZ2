#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>
#include <fstream>


#define KEY 0x1111

struct sembuf p = {0, -1, SEM_UNDO}; // операция P (wait)
struct sembuf v = {0, +1, SEM_UNDO}; // операция V (signal)

int main(int argc, char *argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " philosopher_number\n";
        return 1;
    }
    int philosopher_num = std::stoi(argv[1]); // Идентификатор философа из аргументов командной строки
    int semid = semget(KEY, 1, 0666 | IPC_CREAT);
    int shmid = shmget(KEY, sizeof(int), 0644 | IPC_CREAT);
    int *forks = static_cast<int *>(shmat(shmid, NULL, 0));

    // Открываем файл для записи
    FILE *file = fopen("philosophers_log.txt", "a");
    if (file == NULL) {
        perror("Failed to open file");
        exit(1);
    }

    int left = getpid() % 5;   // Индекс левой вилки
    int right = (left + 1) % 5; // Индекс правой вилки

    while (1) {
        fprintf(file, "Philosopher %d is thinking.\n", philosopher_num);
        fflush(file);  // Сбрасываем буфер, чтобы запись появилась в файле сразу
        sleep(2);

        semop(semid, &p, 1); // Блокировать левую вилку
        fprintf(file, "Philosopher %d took left fork.\n", getpid());
        fflush(file);  // Сбрасываем буфер, чтобы запись появилась в файле сразу
        semop(semid, &p, 1); // Блокировать правую вилку

        fprintf(file, "Philosopher %d is eating.\n", getpid());
        fflush(file);
        sleep(2);

        semop(semid, &v, 1); // Освободить левую вилку
        semop(semid, &v, 1); // Освободить правую вилку
    }

    shmdt(forks);
    fclose(file);  // Закрываем файл
    return 0;
}
